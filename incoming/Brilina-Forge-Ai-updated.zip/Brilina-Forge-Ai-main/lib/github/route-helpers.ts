import { GithubError } from "./api"

export const MAX_ALLOWED_REPOS = 50

// State-changing plugin routes are cookie-authenticated, so reject cross-site
// browser requests even though Supabase cookies are SameSite=Lax.
export function isSameOrigin(request: Request) {
  const origin = request.headers.get("origin")
  if (!origin) return true // non-browser clients and same-origin GETs omit it
  try {
    const originHost = new URL(origin).host
    const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? new URL(request.url).host
    return originHost === host
  } catch {
    return false
  }
}

export function forbiddenOrigin() {
  return Response.json({ error: "cross_origin_request_blocked" }, { status: 403 })
}

export function githubErrorResponse(error: unknown, fallback: string) {
  if (error instanceof GithubError) {
    // GitHub's own 401 means the token is bad; do not surface it as our 401,
    // which the app treats as "signed out".
    const status = error.status === 401 ? 400 : error.status >= 500 ? 502 : error.status
    return Response.json({ error: error.message }, { status })
  }
  return Response.json({ error: fallback }, { status: 500 })
}

export function oauthConfig(getEnv: (name: string) => string | undefined) {
  const clientId = getEnv("GITHUB_OAUTH_CLIENT_ID")
  const clientSecret = getEnv("GITHUB_OAUTH_CLIENT_SECRET")
  return clientId && clientSecret ? { clientId, clientSecret } : null
}
